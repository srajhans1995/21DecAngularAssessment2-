export class Category {
    category: string;
    constructor(category: string) {
        this.category = category;
    }
}